A Pen created at CodePen.io. You can find this one at https://codepen.io/christopher4lis/pen/akRzOr.

 Day 42 - Submission 16

Last and final piece for my CodePen challenge where I started coding one pen every two days, eventually devolving into once every three days, and finally my last one being once on the sixth day. As the concepts behind the code got tougher, the longer I found myself focusing on the same pens.

This one resembles the beginnings to my new portfolio site. Quite proud of myself on this one, stuck through many moments of failure, and was actually strolling through my apartment with fists in the air once I solved the problem that was giving me the most trouble. 

Learned a ton throughout the challenge, but it really is only a beginning. Next challenge on the list (as noted by the pen), resurrecting my portfolio site from the depths of an unpaid Bluehost account, and winning an Awwward. 

August 31, 2016, here we go.