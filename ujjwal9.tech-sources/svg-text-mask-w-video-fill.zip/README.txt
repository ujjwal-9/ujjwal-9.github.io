A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/QvvEYQ.

 An editable SVG text mask with HTML5 video fill.