A Pen created at CodePen.io. You can find this one at https://codepen.io/nevernotsean/pen/ENQgoW.

 A super neat slider using Greensock's Draggable plugin